-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 17-Jun-2020 às 23:39
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `papelaria`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `acessorios_informatica`
--

CREATE TABLE `acessorios_informatica` (
  `id` int(11) NOT NULL,
  `cod_acessorios` int(11) DEFAULT NULL,
  `nome_acessorios` varchar(100) DEFAULT NULL,
  `quantidade_acessorios` int(11) DEFAULT NULL,
  `valor_unit_acessorios` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos_papelaria`
--

CREATE TABLE `produtos_papelaria` (
  `id` int(11) NOT NULL,
  `cod_prod_papelaria` int(11) DEFAULT NULL,
  `nome_prod_papelaria` varchar(100) DEFAULT NULL,
  `quant_prod_papelaria` int(11) DEFAULT NULL,
  `valor_unit_prod` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `servicos_informatica`
--

CREATE TABLE `servicos_informatica` (
  `id` int(11) NOT NULL,
  `cod_serv_infor` int(11) DEFAULT NULL,
  `nome_serv` varchar(100) DEFAULT NULL,
  `quant_serv` int(11) DEFAULT NULL,
  `valor_unit_serv` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `servicos_informatica`
--

INSERT INTO `servicos_informatica` (`id`, `cod_serv_infor`, `nome_serv`, `quant_serv`, `valor_unit_serv`) VALUES
(1, 1, 'XEROX PB TEXTO', NULL, 0.5);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `acessorios_informatica`
--
ALTER TABLE `acessorios_informatica`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `produtos_papelaria`
--
ALTER TABLE `produtos_papelaria`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `servicos_informatica`
--
ALTER TABLE `servicos_informatica`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `acessorios_informatica`
--
ALTER TABLE `acessorios_informatica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `produtos_papelaria`
--
ALTER TABLE `produtos_papelaria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `servicos_informatica`
--
ALTER TABLE `servicos_informatica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
